package me.ham;

public class Util {
    public static void printDash(){
        System.out.println("-------------------------------------------------------");
    }
}

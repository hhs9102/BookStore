package me.ham.product;

public enum Type {
    CLASS, KIT
}

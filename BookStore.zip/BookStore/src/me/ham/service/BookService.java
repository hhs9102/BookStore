package me.ham.service;

import me.ham.user.User;

public interface BookService {
    void order(User user);
}
